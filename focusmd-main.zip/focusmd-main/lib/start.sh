while true
do
echo "Starting FOCUS-XMD!"
node .
done
